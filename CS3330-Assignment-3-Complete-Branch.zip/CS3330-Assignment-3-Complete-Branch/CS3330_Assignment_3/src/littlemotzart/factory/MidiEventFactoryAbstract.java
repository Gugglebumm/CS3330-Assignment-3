package littlemotzart.factory;

import javax.sound.midi.*;

public abstract class MidiEventFactoryAbstract {
    public abstract MidiEvent createNoteOn(int tick, int note, int velocity, int channel) throws InvalidMidiDataException;
    public abstract MidiEvent createNoteOff(int tick, int note, int channel) throws InvalidMidiDataException;
}
