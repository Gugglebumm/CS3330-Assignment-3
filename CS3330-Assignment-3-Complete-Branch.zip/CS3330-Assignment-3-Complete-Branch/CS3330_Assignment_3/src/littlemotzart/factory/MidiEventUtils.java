package littlemotzart.factory;

import javax.sound.midi.MidiEvent;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.InvalidMidiDataException;

public class MidiEventUtils {
    
    public static String formatMidiEvent(MidiEvent event) {
        StringBuilder sb = new StringBuilder();
        sb.append("Tick: ").append(event.getTick()).append(", ");
        
        try {
            ShortMessage message = (ShortMessage) event.getMessage();
            sb.append("Message: ")
                .append("Command: ").append(message.getCommand()).append(", ")
                .append("Channel: ").append(message.getChannel()).append(", ")
                .append("Data1 (Note): ").append(message.getData1()).append(", ")
                .append("Data2 (Velocity): ").append(message.getData2());
        } catch (ClassCastException e) {
            sb.append("Non-ShortMessage Event (Unable to format)");
        }

        return sb.toString();
    }

    public static void main(String[] args) {
        try {
            ShortMessage noteOnMessage = new ShortMessage();
            noteOnMessage.setMessage(ShortMessage.NOTE_ON, 0, 60, 93); // Channel 0, Note 60, Velocity 93
            MidiEvent noteOnEvent = new MidiEvent(noteOnMessage, 0);
            
            ShortMessage noteOffMessage = new ShortMessage();
            noteOffMessage.setMessage(ShortMessage.NOTE_OFF, 0, 60, 0); // Channel 0, Note 60, Velocity 0
            MidiEvent noteOffEvent = new MidiEvent(noteOffMessage, 500);
            
            // Print formatted events
            System.out.println("Created Note On event: " + formatMidiEvent(noteOnEvent));
            System.out.println("Created Note Off event: " + formatMidiEvent(noteOffEvent));
        } catch (InvalidMidiDataException e) {
            e.printStackTrace();
        }
    }
}
