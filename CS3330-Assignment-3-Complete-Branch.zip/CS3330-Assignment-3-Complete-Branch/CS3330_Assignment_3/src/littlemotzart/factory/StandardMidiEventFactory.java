package littlemotzart.factory;

import javax.sound.midi.*;

public class StandardMidiEventFactory extends MidiEventFactoryAbstract {

    @Override
    public MidiEvent createNoteOn(int tick, int note, int velocity, int channel) throws InvalidMidiDataException {
        ShortMessage message = new ShortMessage();
        message.setMessage(144, channel, note, velocity); // Command 144 = Note On
        return new MidiEvent(message, tick);
    }

    @Override
    public MidiEvent createNoteOff(int tick, int note, int channel) throws InvalidMidiDataException {
        ShortMessage message = new ShortMessage();
        message.setMessage(128, channel, note, 0); // Command 128 = Note Off
        return new MidiEvent(message, tick);
    }
}
