package littlemotzart.Midi;

public class MidiEventData {
    private int startEndTick, velocity, note, channel, noteOnOff;
    private int instrument;

    public MidiEventData(int startEndTick, int velocity, int note, int channel, int instrument, int noteOnOff) {
        this.startEndTick = startEndTick;
        this.velocity = velocity;
        this.note = note;
        this.channel = channel;
        this.instrument = instrument;
        this.noteOnOff = noteOnOff;
    }

    // Getters and Setters
    public int getStartEndTick() { return startEndTick; }
    public int getVelocity() { return velocity; }
    public int getNote() { return note; }
    public int getChannel() { return channel; }
    public int getInstrument() { return instrument; }
    public int getNoteOnOff() { return noteOnOff; }
}
