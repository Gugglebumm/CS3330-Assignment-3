package littlemotzart.Midi;

import java.io.*;
import java.util.*;

import javax.sound.midi.ShortMessage;

public class MidiCsvParser {
    public static List<MidiEventData> parseCsv(String filePath) {
        List<MidiEventData> events = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 6) {
                    int startEndTick = Integer.parseInt(parts[0].trim());
                    int noteOnOff = parts[1].contains("on") ? ShortMessage.NOTE_ON : ShortMessage.NOTE_OFF;
                    int channel = Integer.parseInt(parts[2].trim());
                    int note = Integer.parseInt(parts[3].trim());
                    int velocity = Integer.parseInt(parts[4].trim());
                    int instrument = Integer.parseInt(parts[5].trim());
                    events.add(new MidiEventData(startEndTick, velocity, note, channel, instrument, noteOnOff));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return events;
    }
}
