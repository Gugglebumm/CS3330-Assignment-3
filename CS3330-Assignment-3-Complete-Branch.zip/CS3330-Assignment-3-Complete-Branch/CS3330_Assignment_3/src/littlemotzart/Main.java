package littlemotzart;

import javax.sound.midi.*;
import littlemotzart.factory.*;

public class Main {
    public static void main(String[] args) {
        try {
            // Choose a factory (Standard, Legato, Staccato)
            MidiEventFactoryAbstract factoryAbstract = new StandardMidiEventFactory();
            // Uncomment one of the lines below to switch between factories
            // MidiEventFactoryAbstract factoryAbstract = new LegatoMidiEventFactory();
            // MidiEventFactoryAbstract factoryAbstract = new StaccatoMidiEventFactory();

            // Create a Sequence (use Sequence instead of MidiSequence)
            Sequence sequence = new Sequence(Sequence.PPQ, 24);  // PPQ = Pulses Per Quarter Note (standard value)

            // Create a track within the sequence
            Track track = sequence.createTrack();

            // Create NoteOn and NoteOff events using the factory
            MidiEvent noteOn = factoryAbstract.createNoteOn(0, 60, 93, 0); // Tick: 0, Note: 60 (Middle C), Velocity: 93
            track.add(noteOn);
            System.out.println("Created " + noteOn.getMessage());

            MidiEvent noteOff = factoryAbstract.createNoteOff(500, 60, 0); // Tick: 500, Note: 60 (Middle C)
            track.add(noteOff);
            System.out.println("Created " + noteOff.getMessage());

            // Here, you can save the sequence to a file or play it using a MidiPlayer
            // For example: Saving to a MIDI file
            MidiSystem.write(sequence, 1, new java.io.File("output.mid"));

        } catch (InvalidMidiDataException | java.io.IOException e) {
            e.printStackTrace();
        }
    }
}
